#  Game  Memory Card
1. Mô tả ngắn gọn.

    + Memory card -  Lật bài
    
2. Mô tả chi tiết.

    + Những đối tượng trong game:
        - Các loại lá bài
        - Các lá bài đã được lật trước đó

    + Tương tác người chơi
        - Người chơi chạm vào các lá bài, các lá bài sẽ lật lại
    
    + Nếu lật 2 lá bài liên tiếp không trùng nhau thì 2 lá bài sẽ lật úp lại
        - dùng mảng 2 chiều đặt giá trị vào các ô để nhận biết các gía trị của các ô
        
    + Nếu 2 lá bài trùng nhau sẽ để nguyên
    
    + Người chơi chiến thắng khi tất cả các lá bài đều được lật
    + Lật hết trong khoảng thời gian quy đinh là win và chuyển qua màn khó hơn
    + Hết Time mà chưa lật hết là Over
    + Sẽ có điểm thưởng cho mỗi lần lật
    
    + tạo một mảng gồm key và Image
    + tạo một mảng  gồm col*row để chứa key
    + đưa key vào mảng 2 chiều
    + quét mảng 2 chiều theo key hiện ảnh
    
    
    
    

