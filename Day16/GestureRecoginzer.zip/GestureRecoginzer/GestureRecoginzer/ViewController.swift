//
//  ViewController.swift
//  GestureRecoginzer
//
//  Created by Techmaster on 6/13/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    var bricks = Set<Brickss>()
    let col: Int = 10
    let row: Int = 20
    let margin: CGFloat = 1.0
    // tạo mảng  
    private func buildWall() {
        let brickWidth = (view.bounds.width - CGFloat(col+1) * margin) / CGFloat(col)
        let brickHeight: CGFloat = 40.0
        for i in 0..<row {
            var brickRow = [Brickss]()
            for j in 0..<col {
                let brick = Brickss()
                brick.frame = CGRect(x: margin*CGFloat(j+1) + CGFloat(j)*brickWidth,
                                     y: 40.0 + CGFloat(i)*(brickHeight + margin),
                                     width: brickWidth,
                                     height: brickHeight)
                brick.backgroundColor = .gray
                
                view.addSubview(brick)
                brickRow.append(brick)
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(onSwipe(sender:)))
        swipeUp.direction = .up
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(onSwipe(sender:)))
        swipeDown.direction = .down
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(onSwipe(sender:)))
        swipeLeft.direction = .left
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(onSwipe(sender:)))
        swipeRight.direction = .right
        
                
        view.addGestureRecognizer(swipeUp)
        view.addGestureRecognizer(swipeDown)
        view.addGestureRecognizer(swipeLeft)
        view.addGestureRecognizer(swipeRight)
        
        buildWall()
    }
    
    
    
    @objc func onSwipe(sender: UIGestureRecognizer) {
        if let swipe = sender as? UISwipeGestureRecognizer {
            print(swipe.numberOfTouches)
            switch swipe.direction {
            case .up:
                print("up")
            case .down:
                print("down")
            case .left:
                print("left")
            case .right:
                print("right")
            default:
                print("Un")
            }
            
        }
        
    }


}

