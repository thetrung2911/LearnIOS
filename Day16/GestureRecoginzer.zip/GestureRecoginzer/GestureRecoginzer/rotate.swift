//
//  rotate.swift
//  GestureRecoginzer
//
//  Created by Trung Le on 6/13/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import Foundation
func rotateLeft(_ arr: inout [[Int]]){
   
    
}
func rotateRight(_ arr: inout [[Int]]){
    
}


